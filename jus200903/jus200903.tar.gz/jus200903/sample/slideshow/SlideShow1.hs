-- SlideShow ver.1
-- ファイルからそのまま標準入力へ



module Main where

import qualified System.IO.UTF8 as U

main :: IO ()
main = U.readFile "session.txt" >>= U.putStr



