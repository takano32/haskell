-- SlideShow ver.0
-- 標準入力をそのまま標準出力へ



module Main where

import qualified System.IO.UTF8 as U

main :: IO ()
main = U.getContents >>= U.putStr