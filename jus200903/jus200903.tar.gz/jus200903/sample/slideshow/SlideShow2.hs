-- SlideShow ver.2
-- スライドファイル名をコマンドラインで指定



module Main where

import System.Environment
import qualified System.IO.UTF8 as U

main :: IO ()
main = getArgs >>= U.readFile . head >>= U.putStr




