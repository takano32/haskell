-- Haskellによる関数プログラミング
-- List関数（ほんの一部）

import Prelude hiding (map,filter,(++),foldr,foldl,zip,unzip,zipWith)

map :: (a -> b) -> [a] -> [b]
map f (x:xs) = f x : myMap f xs
map _ _      = []

filter :: (a -> Bool) -> [a] -> [a]
filter p (x:xs) | p x       = x : myFilter p xs
                  | otherwise = myFilter p xs

(++) :: [a] -> [a] -> [a]
[]     ++ ys = ys
xs     ++ [] = xs
(x:xs) ++ ys = x : (xs ++ ys)

foldr :: (a -> b -> b) -> b -> [a] -> b
foldr o z (x:xs) = x `o` foldr o z xs
foldr _ z []     = z

foldl :: (a -> b -> a) -> a -> [b] -> a
foldl o z (x:xs) = foldl o (z `o` x) xs
foldl _ z []     = z

unfold :: (a -> Bool) -> (a -> b) -> (a -> a) -> a -> [b]
unfold p f g x = if p x then [] else f x : unfold p f g (g x)

zip :: [a] -> [b] -> [(a,b)]
zip (x:xs) (y:ys) = (x,y) : zip xs ys
zip _      _      = []

unzip :: [(a,b)] -> ([a],[b])
unzip ((x,y):zs) = (x:xs,y:ys) where (xs,ys) = unzip zs

zipWith :: (a -> b -> c) -> [a] -> [b] -> [c]
zipWith f (x:xs) (y:ys) = f x y : zipWith f xs ys
zipWith _ _      _      = []

--------------------------------------------------------------------
myMap f xs = foldr o [] xs
  where x `o` ys = f x : ys

mayMap' f = foldr ((:) . f)

myFilter p xs = foldr o [] xs
  where x `o` ys | p x       = x : ys
                 | otherwise = ys

myAppend xs ys = foldr (:) ys xs

myUnzip zs = foldr o ([],[]) zs
  where (x,y) `o` (xs,ys) = (x:xs,y:ys)
