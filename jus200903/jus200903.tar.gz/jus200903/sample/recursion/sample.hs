-- Fizz-Buzz 問題

fizz,buzz :: [String]
fizzBuzz = zipWith f [0..] (zipWith (++) fizz buzz)
  where
    f n "" = show n
    f _ s  = s

fizz = cycle (take 3 ("Fizz":repeat ""))
buzz = cycle (take 5 ("Buzz":repeat ""))

answer1 = take 100 (tail fizzBuzz)

-- 素数列

primes :: [Integer]
primes = sieve [2..]

sieve :: [Integer] -> [Integer]
sieve (p:qs) = p : sieve (filter ((0 /=) . (`mod` p)) qs)

answer2 = take 100 primes

-- Pascalの三角形

pascal :: [[Integer]]
pascal = [1]:[zipWith (+) ([0]++p) (p++[0]) | p <- pascal]

answer3 = take 20 pascal
