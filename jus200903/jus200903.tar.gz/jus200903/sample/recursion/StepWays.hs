-- Haskellによる関数プログラミング(2)
{-# OPTIONS_GHC -cpp #-}

#ifndef __STEPWAYS
-- StepWaysモジュール ver.0 --------------------------------------------

module StepWays where

stepWays :: Integer -> Integer
stepWays 0 = 1
stepWays 1 = stepWays 0
stepWays n = stepWays (n-2) + stepWays (n-1)
-- O(φ^n)
-- stepWays 30 を試してみましょう．

#elif __STEPWAYS == 1
-- StepWaysモジュール ver.1 --------------------------------------------

module StepWays where

stepWays :: Integer -> Integer
stepWays 0 = 1
stepWays 1 = stepWays 0
stepWays n = stepWays (n-2) + stepWays (n-1)
-- O(φ^n)
-- stepWays 30 を試してみましょう．

-- fastStepWays
stepWays2 :: Integer -> (Integer, Integer)
stepWays2 0 = (1,1)
stepWays2 n = (b,a+b) where (a,b) = stepWays2 (n-1)

fastStepWays :: Integer -> Integer
fastStepWays = fst . stepWays2
-- O(n)
-- fastStepWays (10^5) を試してみましょう．

#elif __STEPWAYS == 2
-- StepWaysモジュール ver.2 --------------------------------------------

module StepWays where

stepWays :: Integer -> Integer
stepWays 0 = 1
stepWays 1 = stepWays 0
stepWays n = stepWays (n-2) + stepWays (n-1)
-- O(φ^n)
-- stepWays 30 を試してみましょう．

-- fastStepWays
stepWays2 :: Integer -> (Integer, Integer)
stepWays2 0 = (1,1)
stepWays2 n = (b,a+b) where (a,b) = stepWays2 (n-1)

fastStepWays :: Integer -> Integer
fastStepWays = fst . stepWays2
-- O(n)
-- fastStepWays (10^5) を試してみましょう．

--veryFastStepWays
fastStepWays2 :: Integer -> (Integer, Integer)
fastStepWays2 0 = (1,1)
fastStepWays2 n | even n    = (c,d)
                | otherwise = (d,c+d)
      where (c,d) = (a^2+(b-a)^2,2*(2*b-a))
            (a,b) = fastStepWays2 (n `div` 2)

veryFastStepWays :: Integer -> Integer
veryFastStepWays = fst . fastStepWays2

-- O(log n)
-- veryFastStepWays (10^7) を試してみましょう．

#endif

