-- BMIモジュール ver.5 -------------------------------------

module BMI where

type BMI = Double

stdBMI :: BMI
stdBMI = 22.0

type Height = Double
type Weight = Double

bmi :: (Height,Weight) -> BMI
bmi (h,w) = w / h^2

-- 特定の身長の人専用のbmi関数

bmi171，bmi155 :: Weight -> BMI
bmi171 w = bmi (1.71,w)
bmi155 w = bmi (1.55,w)

