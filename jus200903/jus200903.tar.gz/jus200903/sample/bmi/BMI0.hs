-- BMIモジュール ver.0 -------------------------------------

module BMI where

type BMI = Double

stdBMI :: BMI
stdBMI = 22.0
