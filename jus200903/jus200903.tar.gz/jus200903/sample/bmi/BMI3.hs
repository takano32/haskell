-- BMIモジュール ver.3 -------------------------------------

module BMI where

type BMI = Double

stdBMI :: BMI
stdBMI = 22.0

type Height = Double
type Weight = Double

bmi :: (Height,Weight) -> BMI
bmi (h,w) = "never!"           -- 型エラー

