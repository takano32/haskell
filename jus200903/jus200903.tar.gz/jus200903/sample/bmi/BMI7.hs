-- BMIモジュール ver.7 -------------------------------------

module BMI where

type BMI = Double

stdBMI :: BMI
stdBMI = 22.0

type Height = Double
type Weight = Double

bmi :: (Height,Weight) -> BMI
bmi (h,w) = w / h^2

-- 特定の身長の人専用のbmi関数

bmi171，bmi155 :: Weight -> BMI
bmi171 = mkbmi 1.71
bmi155 = mkbmi 1.55

-- 特定の身長の人専用のbmi関数を作る関数

mkbmi :: Height ->  Weight -> BMI
mkbmi h w = bmi (h,w)

